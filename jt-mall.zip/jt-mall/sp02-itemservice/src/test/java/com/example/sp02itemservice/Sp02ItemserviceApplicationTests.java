package com.example.sp02itemservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sp02ItemserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
