package com.example.sp03userservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Sp03UserserviceApplicationTests {

    @Test
    void contextLoads() {
    }

}
