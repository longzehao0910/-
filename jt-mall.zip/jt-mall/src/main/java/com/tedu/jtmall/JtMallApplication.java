package com.tedu.jtmall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JtMallApplication {

    public static void main(String[] args) {
        SpringApplication.run(JtMallApplication.class, args);
    }

}
