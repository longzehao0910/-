package com.tedu.jtmall;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JtMallApplicationTests {

    void contextLoads() {
    }

}
